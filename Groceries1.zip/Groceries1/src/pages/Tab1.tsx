import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Tab1.css';

const GroceryList: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>GroceryList</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">GroceryList</IonTitle>
          </IonToolbar>
        </IonHeader>
        <ExploreContainer name="Tab 1 page" />
      </IonContent>
    </IonPage>
  );
};


import React from 'react';
import { IonItem, IonLabel, IonList } from '@ionic/react';

function Example() {
  return (
    <IonList>
      <IonItem>
        <IonLabel>Milk</IonLabel>
      </IonItem>
      <IonItem>
        <IonLabel>Bread</IonLabel>
      </IonItem>
      <IonItem>
        <IonLabel>Eggs</IonLabel>
      </IonItem>
      <IonItem>
        <IonLabel>Butter</IonLabel>
      </IonItem>
      <IonItem>
        <IonLabel>Waffles</IonLabel>
      </IonItem>
    </IonList>
  );
}
export default Example;